#————————————————————————————————   IMPORTATIONS  ——————————————————————————————— #

from random import randint
from tkinter import *

#========================================================================

def somme(elements_case):
    "calcul la somme des éléments d'une liste"
    somme=0
    for valeur in elements_case:
        somme = somme+valeur
    return somme


def produit(elements_case):
    "calcul le produit des éléments d'une liste"
    prod=1
    for valeur in elements_case:
        prod = prod*valeur
    return prod


def difference(elements_case):
    """se baser sur une liste
    faire toujours la difference du plus grand et l'elemnt le plus grand après lui
    jusqu'à ce qu'il reste un seul élément
    """
    dif = 0
    while elements_case:
        if len(elements_case)>=2:
            max1 = max(elements_case)
            elements_case.remove(max1)
            max2=max(elements_case)
            elements_case.remove(max2)
            dif = max1-max2
            elements_case.append(dif)
            if len(elements_case)==1:
                dif = max(elements_case)
                elements_case.remove(dif)
        elif(len(elements_case)==1):
            dif = elements_case[0]
            elements_case.remove(dif)
    return dif
    

def calcul_somme(elements_case1, elements_case2, elements_case3):
    """faire la somme des des éléments de chaque liste(des " cases),
    mettre les 3 resultats dans une liste"""
    
    
    somme1 = somme(elements_case1)
    somme2 = somme(elements_case2)
    somme3 = somme(elements_case3)
    
   
    return [somme1, somme2, somme3]

def calcul_produit(elements_case1, elements_case2, elements_case3):
    """faire le produit des des éléments de chaque liste(des " cases),
    mettre les 3 resultats dans une liste"""
    
    
    prod1 = produit(elements_case1)
    prod2 = produit(elements_case2)
    prod3 = produit(elements_case3)
        
        
    return  [prod1, prod2, prod3]
        
def calcul_difference(elements_case1, elements_case2, elements_case3):
    """faire la difference des des éléments de chaque liste(des " cases),
    mettre les 3 resultats dans une liste"""
    
    
    dif1 = difference(elements_case1)
    dif2 = difference(elements_case2)
    dif3 = difference(elements_case3)
    
    return [dif1, dif2, dif3]


def NivRead(index=0):
    "lire le niveau dans le doc"
    f = open('doc.txt', "r")
    data=f.read().split("\n")
    return data[index]

def NivWrite(niv,index=0):
    "Ecreire le niveau dans le doc"
    f = open('doc.txt', "r")
    l=f.readlines()
    l[index]=str(niv)+"\n"
    f = open('doc.txt', "w")
    f.writelines(l)
    f.close()

    
def levels(l2,niveau):
    "la fonction de ressource pour ce jeu : structure de données"
    l1=[randint(1,9) for i in range(6)]
    copy_l1 = l1.copy()
    NivWrite(l1,2)
    while copy_l1:
        x = randint(0,len(copy_l1)-1)
        val = copy_l1.pop(x)
        l2.append(val)
    
    liste_chiffres_a_jouer1 = l2[0:2]
    liste_chiffres_a_jouer2 = l2[2:4]
    liste_chiffres_a_jouer3 = l2[4:6]
    
    if 1<=niveau<=10:
        resultats_attendus = calcul_somme(liste_chiffres_a_jouer1, liste_chiffres_a_jouer2, liste_chiffres_a_jouer3)
    elif 11<=niveau<=20:
        resultats_attendus = calcul_produit(liste_chiffres_a_jouer1, liste_chiffres_a_jouer2, liste_chiffres_a_jouer3)
    else:
        resultats_attendus = calcul_difference(liste_chiffres_a_jouer1, liste_chiffres_a_jouer2, liste_chiffres_a_jouer3)
    NivWrite(resultats_attendus,1)
    return [""]+resultats_attendus

#==============================ça marche========================

def obtenir_valeurs_dans_rectangles(L1, L2, L3,niveau):
    """ontenir les valeur numérique des images placées dans 
    les cases et appliquer la métode de calcul selon le niveau"""
    
    elements_case1, elements_case2, elements_case3 = [], [], []
    
    for tag1 in L1:
        listags = tag1.split("-")
        chiffre = int(listags[1])
        elements_case1.append(chiffre)
        
    for tag2 in L2:
        listags = tag2.split("-")
        chiffre = int(listags[1])
        elements_case2.append(chiffre)

    
    for tag3 in L3:
        listags = tag3.split("-")
        chiffre = int(listags[1])
        elements_case3.append(chiffre)

        
    print(elements_case1)
    print(elements_case2)
    print(elements_case3)
    
    global resultats_a_tester
  
  
    if 1<=niveau<=10:
        resultats_a_tester = calcul_somme(elements_case1, elements_case2, elements_case3)
    elif 11<=niveau<=20:
        resultats_a_tester = calcul_produit(elements_case1, elements_case2, elements_case3)
    else:
        resultats_a_tester = calcul_difference(elements_case1, elements_case2, elements_case3)
    NivWrite(resultats_a_tester,3)