#————————————————————————————————   IMPORTATIONS  ——————————————————————————————— #
import pygame
from tkinter import *
from subprocess import call
from generateur_niveau import NivWrite

#————————————————————————————————   FAIRE SES CHOIX AVANT LE DEMMARAGE DU JEU : LANCER  ——————————————————————————————— #

def nouvellePartie():
    "Lancer le jeu là où on s'est arreté"
    call(["python", "fonctions.py"])

def exit():
    "Annuler le jeu"
    fen.destroy()

def add():
    "Lancer la partie addition"
    NivWrite(1)
    call(["python", "fonctions.py"])
    
def prod():
    "Lancer la prtie multiplication"
    NivWrite(11)
    call(["python", "fonctions.py"])
    
def diff():
    "Lancer la partie soustraction"
    NivWrite(21)
    call(["python", "fonctions.py"])
    
    
def activer_son():
    "Activer le son du jeu"
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("sons/son.mp3")
    pygame.mixer.music.play(-1)


#————————————————————————————————   lES ELEMENTS GRAPHIQUE  ——————————————————————————————— #

fen=Tk()
fen.title('MATHS BLOCKS')
fen.geometry("600x350")
fondImage = PhotoImage(file="images/Ima.png")
can=Canvas(fen, width=600, heigh=400)


can.create_image(150, 100, image=fondImage)
lbl=Label(fen,text="MATHEMATICS BLOCKS ",font=30, width=50)
b1 = Button(can, text='Jouer', bg="#b4b7df",command=nouvellePartie, width=30) # jouer à partir de  là on s'est
b2 = Button(can, text='Quitter', bg="#b4b7df",command=exit,  width=15) #quitter le jeu
b3 = Button(can, text='addition', bg="#b4b7df",command=add,  width=15) # faire la partie addition
b4 = Button(can, text='différence', bg="#b4b7df",command=diff,  width=15) # faire la partie difference
b5 = Button(can, text='multiplication', bg="#b4b7df",command=prod,  width=15) # faire la partie mutiplication
buton_son = Button(can, text='Activer le son', bg="#b4b7df",command=activer_son,  width=30) # activer le son

# positionnement de nos bouttons et labels
lbl.place(relx=0.12,rely=0.1)
b1.place(relx=0.35, rely=0.3)
b2.place(relx=0.7, rely=0.7)
b3.place(relx=0.1, rely=0.5)
b4.place(relx=0.7, rely=0.5)
b5.place(relx=0.1, rely=0.7)
buton_son.place(relx=0.35, rely=0.9)

can.pack()
fen.eval('tk::PlaceWindow . center')
fen.mainloop()