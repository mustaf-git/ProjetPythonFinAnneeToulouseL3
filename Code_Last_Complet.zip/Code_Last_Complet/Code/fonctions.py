#————————————————————————————————   IMPORTATIONS  ——————————————————————————————— #

from tkinter import *
from timeit import default_timer
from generateur_niveau import *

#========================================================================

#===================

#———————————————————————————————————————————  L'INTERFACE PAGE DU JEU   ——————————————————————————————————————— #

def afficher_partie():
    if 1<=niveau<=10:
        return "Addition"
    elif 11<=niveau<=20:
        return "Multiplication"
    else:
        return "Soustraction" 
    
    
def afficher_temps():
    now = default_timer() - debut
    minutes, seconds = divmod(now, 60)
    str_time = "%d:%02d" % (minutes, seconds)
    temps["text"]="temps : "+str_time
    fen.after(1000, afficher_temps)
    
    
def creer_rectangle_result(x,y,cote,couleurs):
    "Créer les rectangles ou afficher les resultats du joueurs"
    for i in range(1,4):
        rect_res = canvas.create_rectangle(i*x, y, i*x+cote, y+cote, outline=couleurs[i])


def creer_rectangle_proposition(x,y,cote,couleurs):
    "Créer les rectangles ou placer les chiffres pour obtenir un resultat dans chaque case"
    i=1
    while i<=3:
        rect_prop=canvas.create_rectangle(x, y, x+cote, y+cote, outline=couleurs[i])
        x=x+cote/2
        y=y+cote/2
        i+=1
        
        
def creer_rectangle_chiffre_a_jouer(x,y,cote):
    "creer les rectangles ou placer les chiffres disponibles pour chaque niveau du jeu"
    i=1
    while i<=6:
        rect_chiffre = canvas.create_rectangle(x, y, x+cote, y+cote, outline="white")
        x=x+2*cote
        i+=1

        
def image_centre(tag):
        """ Renvoie le centre de l'image
        """
        x1, y1 = canvas.coords(tag)
        return x1 , y1

def calcul_centre(x1, y1, x2, y2):
    """renvoie le centre du rectangle
    """
    return (x1+x2)/2, (y1+y2)/2


def obtenir_position_chiffre_a_jouer(cordonnes):
    """obtenir toutes les cordoonnees (les centres des rectangles)
    ou placer les chiffres du jeu"""
    global ListeCentre
    ListeCentre = []  
    
    for imagex1, imagex2, imagey1, imagey2 in cordonnes:
        centre = calcul_centre(imagex1,imagey1,imagex2,imagey2)
        ListeCentre.append(centre)


def obtenir_les_chiffres_a_jouer(liste_chiffres_a_jouer):
    """se baser sur les chiffres générer aléatoirement 
        pour récupérer les images corespondantes"""
    global ListeImage
    ListeImage = []
    
    for chiffre in liste_chiffres_a_jouer:
        img = PhotoImage(file="images/Sans-titre---{}.png".format(chiffre)).zoom(3).subsample(32)
        ListeImage.append(img)
  

def inserer_chiffres_a_jouer(liste_chiffres_a_jouer):
    """inserer maintenant les images récupérées au niveau
        des rectangles d'en bas(chiffres du jeu)"""
    for i in range(len(liste_chiffres_a_jouer)):
        print(i)
        chiffre = canvas.create_image(ListeCentre[i], image=ListeImage[i], tags=["chiffre-{}-{}".format(liste_chiffres_a_jouer[i], i)])
        print(canvas.gettags(chiffre))
        canvas.tag_bind(chiffre, '<B1-Motion>', move)
        canvas.tag_bind(chiffre, '<ButtonRelease>', chercher)

#—————————————————————————————————  GERER L'INTERACTION DE l'UTILISATEUR  ————————————————————————————— #


def move(event):
    "déplacer les chiffres"    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = canvas.gettags(CURRENT) # tags contient le tag "rectangle-1" et "current"
    if flag:
        for tag in tags:
            if not tag.startswith("chiffre"):
                continue
            x1, y1 = image_centre(tag)
            canvas.move(tag, x-x1, y-y1)
            
            
        
def chercher(event):
    """
    Recuperer les images(chiffres) placer au niveau des cases
    dans 3 ensembles et les mettres dans 3 listes => chaque liste represente une case
    """
    x,y = event.x, event.y
    tags = canvas.gettags(CURRENT)
    for tag in tags:
        if not tag.startswith("chiffre"):
            continue
        x1, y1 = image_centre(tag)
        x1, y1 = image_centre(tag)
        if x1 in range(180, 330) and y1 in range(210,360):
            print("je suis dans L1")
            print(tag)
            E1.add(tag)
        else:
            if tag in E1:
                E1.remove(tag)
        if x1 in range(255, 405) and y1 in range(285,435):
            E2.add(tag)
        else:
            if tag in E2:
                E2.remove(tag)
        if x1 in range(330, 480) and y1 in range(360,510):
            E3.add(tag)
        else:
            if tag in E3:
                E3.remove(tag)
                
    L1,L2,L3 = list(E1), list(E2), list(E3)
    
    obtenir_valeurs_dans_rectangles(L1, L2, L3,niveau)

    

#—————————————————————————————————  TRAITER LES ACTIONS DE L'UTILISATEUR  ————————————————————————————— #
    
def affiche_resultats_attendus(x,y,cote,couleurs,L):
    "Affiche les resultats qu'on attends pour les differentes couleurs"
    for i in range(1,4):
        bon_result = canvas.create_text(((i*x)+(i*x+cote))/2, y, fill=couleurs[i],text=L[i],font=("Heletica", 15, 'bold') )

def affiche_resultat_joueur(x,y,cote,res_joueur):
    "Afficher les resultats du joueur au niveau des rectangles d'en haut"
    for i in range(1,4):
        resultat_joueur = canvas.create_text(((i*x)+(i*x+cote))/2, ((y)+(y+cote))/2, fill="white",text=res_joueur[i],font=("Heletica", 20))
    # Affiche les notification en fonction des reponses
    
    afficher_notif_reponse(170, 90, 70, resultats_attendus, eval(NivRead(3)))

def afficher_notif_reponse(x, y, cote, res_attendu, res_joueur):
    """Afficher les notifications de trouvé ou non trouvé en fonction des  réponses,
    initialiser la même partie ou ,
    psser au leavel suivant"""
    
    global notifs,niveau,resultats_a_tester,flag
    notifs = []
    ListeCentre = [] # 3centres
    image_trouve = PhotoImage(file="images/trouve.png").zoom(1).subsample(32)
    image_non_trouve = PhotoImage(file="images/non_trouve.png").zoom(1).subsample(32)
    notifs.append(image_trouve)
    notifs.append(image_non_trouve)
    #print(notifs)
    for i in range(1,4):
        if i==2:
            centre = ((i*x)+(i*x+(cote-30)))/2, ((y)+(y+cote))/2
            ListeCentre.append(centre)
        elif i==3:
            centre = ((i*x)+(i*x+(cote-70)))/2, ((y)+(y+cote))/2
            ListeCentre.append(centre)
        else:
            centre = ((i*x)+(i*x+cote))/2, ((y)+(y+cote))/2
            ListeCentre.append(centre)
    print(centre)
    
    tout_trouve = True
    for j in range(len(res_attendu)):
        print(res_attendu,res_joueur)
        if res_attendu[j] == res_joueur[j]:
            canvas.create_image(ListeCentre[j], image=notifs[0])
        else:
            canvas.create_image(ListeCentre[j], image=notifs[1])
            tout_trouve = False
    if(tout_trouve):
        niveau+=1
        NivWrite(niveau)
    else:
        flag=0
        


def jeu():
    "Lancer le jeu" 
    global flag,E1,E2,E3
    flag=1
    canvas.delete("all")
    niv["text"]="Niveau : "+str(niveau)
    partie["text"]="Partie : "+afficher_partie()
    NivWrite([],3)
    E1,E2,E3 = set(), set(), set()

    affiche_resultats_attendus(150,60,70,couleurs=["", "green", "yellow", "red"], L = level)
    creer_rectangle_result(150,70,70,couleurs = ["","green", "yellow", "red"])
    creer_rectangle_proposition(180,210,150,couleurs = ["","green", "yellow", "red"])
    creer_rectangle_chiffre_a_jouer(50,580,50)
    obtenir_position_chiffre_a_jouer(cordonnes)
    l=eval(NivRead(2))
    obtenir_les_chiffres_a_jouer(l)
    inserer_chiffres_a_jouer(l)
    
    
def suivant():
    "Passer au niveau suivant"
    global niveau,level,resultats_attendus
    if flag:
        niveau = int(NivRead())
        level=levels([],niveau)
        resultats_attendus=eval(NivRead(1))
        jeu()

    
#============== on est dessus pour rammener le chiffre à sa position initiale si il n'est pas bien placé ========

def remener(event):
    "retourner le chiffre mal déplacé à sa position initiale"
    print(ListeCentre)
    print(ListeImage)
    x,y = event.x, event.y
    tags = canvas.gettags(CURRENT)
    for tag in tags:
        if not tag.startswith("chiffre"):
            continue
        x1, y1 = image_centre(tag)
        if (x1 in range(180, 330) and y1 in range(180,330)) or (x1 in range(255, 405) and y1 in range(255,405)) or (x1 in range(330, 480) and y1 in range(330,480)):
            print("je suis dans un rectangle")
        else:
            print("je ne suis pas dans un rectangle donc je dois retourner à ma position")
            print(x,y)
            print(x1, y1)
            #canvas.move(tag, x1-x,y1-y)
            


#———————————————————————————————————————————  DEFINITION DES VARIABLES ———————————————————— ——————————————————— #

cordonnes = [
    [50, 100, 580, 630],
    [150, 200, 580, 630],
    [250, 300, 580, 630],
    [350, 400, 580, 630],
    [450, 500, 580, 630],
    [550, 600, 580, 630]
]

niveau = int(NivRead())
level=levels([],niveau)
resultats_attendus=eval(NivRead(1))
flag=1

E1,E2,E3 = set(), set(), set()

debut = default_timer()


#———————————————————————————————————————————  Affichage  ——————————————————————————————————————— #

fen = Tk() ##création d’une instance
fen.title('MATHS BLOCKS')
canvas = Canvas(fen, width=650, height=680, bg="#12153d")
canvas.pack(side=LEFT, padx =5, pady =5)

#================

boutton1 = Button(fen, text='Suivant', width =14, height =2, background ="#b6b8d4",command=suivant) # passer au niveau suivant
boutton1.pack(side=TOP)

boutton2 = Button(fen, text='Calculer', width =14, height =2, background ="#b6b8d4", command=lambda : affiche_resultat_joueur(150,70,70,[""]+eval(NivRead(3)))) # afficher le resultat de mon calcul
boutton2.pack(pady=100)

boutton4 = Button(fen, text='Ressayer', width =14, height =2, background ="#b6b8d4",command=jeu) # Ressayer
boutton4.pack(pady=20)

boutton3 = Button(fen, text='Quitter', width =14, height =2, background ="#b6b8d4", command=fen.destroy) # quitter le jeu
boutton3.pack(side=BOTTOM)


#================ Affichage des infos par les labels


niv= Label(fen,bg="white", font=("Heletica", 12, 'bold'), fg="red")
niv.place(relx=0.72,rely=0.02)

temps= Label(fen,bg="black",font=("Heletica", 12, 'bold'), fg="red")
temps.place(relx=0.7,rely=0.3)

partie= Label(fen,bg="white",font=("Heletica", 14, 'bold'), fg="red")
partie.place(relx=0.02,rely=0.02)

#———————————————————————————————————————————  LANCEMENT DU JEU  ————————————————————————————————————————————————— #

jeu()

afficher_temps()

fen.mainloop()